import{G as r,H as a,I as u}from"./entry-43baabdd.mjs";var n=r(async o=>{let e,t;const s=([e,t]=a(()=>u()),e=await e,t(),e);if(s!=null)return"/"});export{n as default};
