import{G as r,H as s,I as o}from"./entry-43baabdd.mjs";var n=r(async u=>{let e,t;const a=([e,t]=s(()=>o()),e=await e,t(),e);if(a==null&&a==null)return"/login"});export{n as default};
