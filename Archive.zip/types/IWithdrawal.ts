export interface IWithdrawal {
    
}