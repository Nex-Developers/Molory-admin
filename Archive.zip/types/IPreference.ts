export interface IPreference {
    id?: number
    createdAt?: string

    question: string
    answer: string
}
