export interface IPricing {
    id?: number
    createdAt?: string
    vehicleTypeName: string
    lowerDistance: string
    upperDistance: string
    unitPrice: number
}