export interface IPayment {
    
}