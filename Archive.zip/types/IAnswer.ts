export interface IAnswer {
    id?: number
    users?: string
    index?: number
    value: string
}
