export interface IVehicleType {
    id?:number
    createdAt?: string
    name: string
    maxSeats: number
    description: string
}